const express = require('express');
const bodyParser = require('body-parser');
const { Sequelize, DataTypes } = require('sequelize');

const app = express();
const port = 3000;

app.use(bodyParser.json());

// Conectare la baza de date MySQL
const sequelize = new Sequelize('database', 'username', 'password', {
  host: 'localhost',
  dialect: 'mysql'
});

// Definirea entităților (ExampleParent și ExampleChild)
const ExampleParent = sequelize.define('ExampleParent', {
  name: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

const ExampleChild = sequelize.define('ExampleChild', {
  description: {
    type: DataTypes.STRING,
    allowNull: false
  }
});

// Relația între entități (One-to-Many)
ExampleParent.hasMany(ExampleChild);
ExampleChild.belongsTo(ExampleParent);

// Crearea tabelelor în baza de date
sequelize.sync();

// Rutele pentru API
app.get('/parents', async (req, res) => {
  const parents = await ExampleParent.findAll({ include: ExampleChild });
  res.json(parents);
});

app.post('/parents', async (req, res) => {
  const { name, children } = req.body;

  // Crearea unui nou părinte împreună cu copiii săi
  const parent = await ExampleParent.create(
    { name, ExampleChildren: children },
    { include: ExampleChild }
  );

  res.json(parent);
});

app.listen(port, () => {
  console.log(`Serverul rulează la adresa http://localhost:${port}`);
});
